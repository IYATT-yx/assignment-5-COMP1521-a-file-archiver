SELECT 'Hello, world!';
